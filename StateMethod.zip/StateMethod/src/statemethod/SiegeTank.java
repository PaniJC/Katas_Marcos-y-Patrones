/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statemethod;

/**
 *
 * @author PaniJC
 */
public class SiegeTank {
    
    public int damage;
    public boolean canMOve;
    public State state;
    public TankState tankState; 
    
    
    
    public void toTankMode(){
        state = (State) tankState;
        damage = 10;
    }
    
}
